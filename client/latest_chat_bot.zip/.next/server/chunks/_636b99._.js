module.exports = {

"[project]/src/components/ui/form.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Form": ()=>Form
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@hookform/resolvers/zod/dist/zod.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const Form = ({ onSubmit, children, useFormProps, validationSchema, fieldErrors, formError, resetValues, className, ...formProps })=>{
    const methods = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"]({
        ...useFormProps,
        ...validationSchema && {
            resolver: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"](validationSchema)
        }
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (resetValues) {
            methods.reset(resetValues);
        }
    }, [
        resetValues,
        methods
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("form", {
        noValidate: true,
        onSubmit: methods.handleSubmit(onSubmit),
        ...formProps,
        className: className,
        children: children(methods)
    }, void 0, false, {
        fileName: "<[project]/src/components/ui/form.tsx>",
        lineNumber: 53,
        columnNumber: 5
    }, this);
};

})()),
"[project]/src/config/routes.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "routes": ()=>routes
});
const routes = {
    eCommerce: {
        dashboard: '/ecommerce',
        products: '/ecommerce/products',
        createProduct: '/ecommerce/products/create',
        productDetails: (slug)=>`/ecommerce/products/${slug}`,
        ediProduct: (slug)=>`/ecommerce/products/${slug}/edit`,
        categories: '/ecommerce/categories',
        createCategory: '/ecommerce/categories/create',
        editCategory: (id)=>`/ecommerce/categories/${id}/edit`,
        orders: '/ecommerce/orders',
        createOrder: '/ecommerce/orders/create',
        orderDetails: (id)=>`/ecommerce/orders/${id}`,
        editOrder: (id)=>`/ecommerce/orders/${id}/edit`,
        reviews: '/ecommerce/reviews',
        shop: '/ecommerce/shop',
        cart: '/ecommerce/cart',
        checkout: '/ecommerce/checkout',
        trackingId: (id)=>`/ecommerce/tracking/${id}`
    },
    searchAndFilter: {
        realEstate: '/search/real-estate',
        nft: '/search/nft',
        flight: '/search/flight'
    },
    support: {
        dashboard: '/support',
        inbox: '/support/inbox',
        supportCategory: (category)=>`/support/inbox/${category}`,
        messageDetails: (id)=>`/support/inbox/${id}`,
        snippets: '/support/snippets',
        createSnippet: '/support/snippets/create',
        viewSnippet: (id)=>`/support/snippets/${id}`,
        editSnippet: (id)=>`/support/snippets/${id}/edit`,
        templates: '/support/templates',
        createTemplate: '/support/templates/create',
        viewTemplate: (id)=>`/support/templates/${id}`,
        editTemplate: (id)=>`/support/templates/${id}/edit`
    },
    logistics: {
        dashboard: '/logistics',
        shipmentList: '/logistics/shipments',
        customerProfile: '/logistics/customer-profile',
        createShipment: '/logistics/shipments/create',
        editShipment: (id)=>`/logistics/shipments/${id}/edit`,
        shipmentDetails: (id)=>`/logistics/shipments/${id}`,
        tracking: (id)=>`/logistics/tracking/${id}`
    },
    candidate: {
        dashboard: '/candidate-dashboard'
    },
    interview: {
        dashboard: '/interview',
        appointmentList: '/interview/list'
    },
    executive: {
        dashboard: '/executive'
    },
    job: {
        dashboard: '/job'
    },
    ScheduleMeeting: {
        dashboard: '/ScheduleMeeting'
    },
    analytics: '/analytics',
    financial: {
        dashboard: '/financial'
    },
    fileManager: {
        dashboard: '/file-manager'
    },
    file: {
        dashboard: '/file',
        manager: '/file-manager-full',
        upload: '/file-manager-full/upload',
        create: '/file-manager-full/create'
    },
    pos: {
        index: '/point-of-sale'
    },
    eventCalendar: '/event-calendar',
    rolesPermissions: '/roles-permissions',
    invoice: {
        home: '/invoice',
        create: '/invoice/create',
        details: (id)=>`/invoice/${id}`,
        edit: (id)=>`/invoice/${id}/edit`
    },
    widgets: {
        cards: '/widgets/cards',
        icons: '/widgets/icons',
        charts: '/widgets/charts',
        maps: '/widgets/maps',
        banners: '/widgets/banners'
    },
    tables: {
        basic: '/tables/basic',
        collapsible: '/tables/collapsible',
        enhanced: '/tables/enhanced',
        pagination: '/tables/pagination',
        search: '/tables/search',
        stickyHeader: '/tables/sticky-header'
    },
    multiStep: '/multi-step',
    forms: {
        profileSettings: '/forms/profile-settings',
        notificationPreference: '/forms/profile-settings/notification',
        personalInformation: '/forms/profile-settings/profile',
        newsletter: '/forms/newsletter'
    },
    emailTemplates: '/email-templates',
    profile: '/profile',
    welcome: '/welcome',
    comingSoon: '/coming-soon',
    accessDenied: '/access-denied',
    notFound: '/not-found',
    maintenance: '/maintenance',
    blank: '/blank',
    auth: {
        signUp1: '/auth/sign-up-1',
        signUp2: '/auth/sign-up-2',
        signUp3: '/auth/sign-up-3',
        signUp4: '/auth/sign-up-4',
        signUp5: '/auth/sign-up-5',
        // sign in
        signIn1: '/auth/sign-in-1',
        signIn2: '/auth/sign-in-2',
        signIn3: '/auth/sign-in-3',
        signIn4: '/auth/sign-in-4',
        signIn5: '/auth/sign-in-5',
        // forgot password
        forgotPassword1: '/auth/forgot-password-1',
        forgotPassword2: '/auth/forgot-password-2',
        forgotPassword3: '/auth/forgot-password-3',
        forgotPassword4: '/auth/forgot-password-4',
        forgotPassword5: '/auth/forgot-password-5',
        // OTP
        otp1: '/auth/otp-1',
        otp2: '/auth/otp-2',
        otp3: '/auth/otp-3',
        otp4: '/auth/otp-4',
        otp5: '/auth/otp-5'
    },
    signIn: '/signin'
};

})()),
"[project]/src/config/messages.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "messages": ()=>messages
});
const messages = {
    passwordOneUppercase: `The Password must contain at least one uppercase character`,
    passwordOneLowercase: `The Password must contain at least one lowercase character`,
    passwordOneNumeric: `The password must contain at least one numerical character.`,
    passwordRequired: 'Password is required',
    passwordLengthMin: 'Password must be at least 6 characters',
    passwordLengthMax: `Password can't be more than 32 characters`,
    newPasswordRequired: 'New Password is required',
    newPasswordLength: 'New Password must be at least 6 characters',
    confirmPasswordRequired: 'Confirm Password is required',
    passwordsDidNotMatch: "Passwords don't match",
    nameIsRequired: 'Name is required',
    firstNameRequired: 'First name is required',
    phoneNumberIsRequired: 'Phone Number is required',
    customerNameIsRequired: 'Customer name is required',
    lastNameRequired: 'Last name is required',
    streetIsRequired: 'Street Address is required',
    emailIsRequired: 'Email address is required',
    invalidEmail: 'Invalid email address',
    roleIsRequired: 'Role is required',
    jobIsRequired: 'Job is required',
    permissionIsRequired: 'Permission is required',
    teamIsRequired: 'New member must be assigned to a team',
    productNameIsRequired: 'Product name is required',
    productTypeIsRequired: 'Product type is required',
    priceIsRequired: 'Product price is required',
    retailPriceIsRequired: 'Retail price is required',
    salePriceIsRequired: 'Sale price is required',
    shippingPriceIsRequired: 'Shipping price is required',
    cityIsRequired: 'City is required',
    stateIsRequired: 'State is required',
    countryIsRequired: 'Country is required',
    addressLineOneRequired: 'Address line 1 is required',
    zipCodeRequired: 'ZIP code is required',
    cardHolderNameIsRequired: 'Card holder name is required',
    cardNumberIsRequired: 'Card Number is required',
    cardExpireIsRequired: 'Expire Date is required',
    cvcNumberIsRequired: 'CVC Number is required',
    catNameIsRequired: 'Category name is required',
    slugIsRequired: 'Slug is required',
    addressIsRequired: 'Address is required',
    createDateIsRequired: 'Create Date is required',
    dueDateIsRequired: 'Due Date is required',
    statusIsRequired: 'Status is required',
    discountIsRequired: 'Discount amount is required',
    taxIsRequired: 'Tax amount is required',
    itemNameIsRequired: 'Item Name is required',
    itemDescIsRequired: 'Item Description is required',
    itemQtyIsRequired: 'Item Quantity is required',
    itemPriceIsRequired: 'Item Price is required',
    fullNameIsRequired: 'Full name is required',
    propertyTypeIsRequired: 'Property type is required',
    placeTypeIsRequired: 'Place type is required',
    amenitiesAreRequired: 'Amenities are required',
    thisFieldIsRequired: 'This Field is required',
    propertyNameIsRequired: 'Property name is required',
    snippetNameIsRequired: 'Snippet name is required',
    snippetDirIsRequired: 'You must have to select a snippet folder',
    templateNameIsRequired: 'Template name is required',
    templateDirIsRequired: 'You must have to select a template folder',
    folderNameIsRequired: 'Folder name is required',
    folderNameLengthMin: 'Folder name must be at least 3 letters',
    productColorRequired: 'Product Color is Required',
    productSizeRequired: 'Product Size is Required',
    descriptionIsRequired: 'Description is Required',
    locationIsRequired: 'Location is Required',
    startDateIsRequired: 'Start Date is required',
    startTimeIsRequired: 'Start Time is required',
    endDateIsRequired: 'End Date is required',
    endTimeIsRequired: 'End Time is required',
    roleNameIsRequired: 'Role Name is Required',
    roleNameLengthMin: 'Role name must be at least 3 letters',
    errorSendingEmail: 'Error sending email',
    emailSentSuccessfully: 'Your email has been sent successfully.',
    meetingScheduleIsRequired: 'Meeting schedule is required'
};

})()),
"[project]/src/utils/validators/common-rules.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fileSchema": ()=>fileSchema,
    "validateConfirmPassword": ()=>validateConfirmPassword,
    "validateEmail": ()=>validateEmail,
    "validateNewPassword": ()=>validateNewPassword,
    "validatePassword": ()=>validatePassword
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/zod/lib/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/config/messages.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const fileSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string(),
    url: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string(),
    size: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].number()
});
const validateEmail = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().min(1, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].emailIsRequired
}).email({
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].invalidEmail
});
const validatePassword = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().min(1, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordRequired
}).min(6, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordLengthMin
}).regex(new RegExp('.*[A-Z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneUppercase
}).regex(new RegExp('.*[a-z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneLowercase
}).regex(new RegExp('.*\\d.*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneNumeric
});
const validateNewPassword = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().min(1, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordRequired
}).min(6, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordLengthMin
}).regex(new RegExp('.*[A-Z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneUppercase
}).regex(new RegExp('.*[a-z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneLowercase
}).regex(new RegExp('.*\\d.*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneNumeric
});
const validateConfirmPassword = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().min(1, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].confirmPasswordRequired
}).min(6, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordLengthMin
}).regex(new RegExp('.*[A-Z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneUppercase
}).regex(new RegExp('.*[a-z].*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneLowercase
}).regex(new RegExp('.*\\d.*'), {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordOneNumeric
});

})()),
"[project]/src/utils/validators/reset-password.schema.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "resetPasswordSchema": ()=>resetPasswordSchema
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/zod/lib/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/config/messages.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$common$2d$rules$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/validators/common-rules.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const resetPasswordSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    email: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$common$2d$rules$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateEmail"],
    password: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$common$2d$rules$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validatePassword"],
    confirmPassword: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$common$2d$rules$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateConfirmPassword"]
}).refine((data)=>data.password === data.confirmPassword, {
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$messages$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["messages"].passwordsDidNotMatch,
    path: [
        'confirmPassword'
    ]
});

})()),
"[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>ForgetPasswordForm
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__ = __turbopack_import__("[project]/node_modules/rizzui/dist/index.mjs [app-ssr] (ecmascript) {locals}");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$form$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/form.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$routes$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/config/routes.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$reset$2d$password$2e$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/validators/reset-password.schema.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
const initialValues = {
    email: '',
    password: '',
    confirmPassword: ''
};
function ForgetPasswordForm() {
    const [reset, setReset] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({});
    const onSubmit = (data)=>{
        console.log(data);
        setReset(initialValues);
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$form$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Form"], {
                validationSchema: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validators$2f$reset$2d$password$2e$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resetPasswordSchema"],
                resetValues: reset,
                onSubmit: onSubmit,
                useFormProps: {
                    mode: 'onChange',
                    defaultValues: initialValues
                },
                className: "pt-1.5",
                children: ({ register, formState: { errors } })=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Input"], {
                                type: "email",
                                size: "lg",
                                label: "Email",
                                placeholder: "Enter your email",
                                className: "[&>label>span]:font-medium",
                                inputClassName: "text-sm",
                                ...register('email'),
                                error: errors.email?.message
                            }, void 0, false, {
                                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                                lineNumber: 42,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Password"], {
                                label: "Password",
                                placeholder: "Enter your password",
                                size: "lg",
                                className: "[&>label>span]:font-medium",
                                inputClassName: "text-sm",
                                ...register('password'),
                                error: errors.password?.message
                            }, void 0, false, {
                                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                                lineNumber: 52,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Password"], {
                                label: "Confirm Password",
                                placeholder: "Enter confirm password",
                                size: "lg",
                                className: "[&>label>span]:font-medium",
                                inputClassName: "text-sm",
                                ...register('confirmPassword'),
                                error: errors.confirmPassword?.message
                            }, void 0, false, {
                                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Button"], {
                                className: "mt-2 w-full",
                                type: "submit",
                                size: "lg",
                                children: "Reset Password"
                            }, void 0, false, {
                                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this)
            }, void 0, false, {
                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
                className: "mt-6 text-center text-[15px] leading-loose text-gray-500 lg:mt-8 lg:text-start xl:text-base",
                children: [
                    "Don’t want to reset your password?",
                    ' ',
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$routes$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["routes"].auth.signIn1,
                        className: "font-bold text-gray-700 transition-colors hover:text-blue",
                        children: "Sign In"
                    }, void 0, false, {
                        fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/app/auth/(forgot-password)/forgot-password-1/forget-password-form.tsx>",
                lineNumber: 76,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}

})()),
"[project]/public/company-logo.jpg [app-ssr] (static)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/company-logo.6e6bf253.jpg");
})()),
"[project]/public/company-logo.jpg.mjs/(IMAGE)/[project]/public/company-logo.jpg [app-ssr] (static) (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$company$2d$logo$2e$jpg__$5b$app$2d$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/company-logo.jpg [app-ssr] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$company$2d$logo$2e$jpg__$5b$app$2d$ssr$5d$__$28$static$29$__["default"],
    width: 795,
    height: 168,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAACAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0DTHcabb4Y/d9a0e5mtj/2Q==",
    blurWidth: 8,
    blurHeight: 2
};

})()),
"[project]/src/app/shared/auth-layout/or-separation.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>OrSeparation
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
function OrSeparation({ title, className, isCenter = false }) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: `before:content-[' '] relative  mt-0.5 flex items-center  before:absolute before:left-0 before:top-1/2 before:h-px before:w-full before:bg-gray-100 ${className} ${isCenter ? 'justify-center' : 'justify-start'}`,
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
            className: `relative z-10 inline-block bg-white text-sm font-medium text-gray-500 2xl:text-base dark:bg-gray-50 ${isCenter ? 'p-2.5' : 'pe-2.5'}`,
            children: title
        }, void 0, false, {
            fileName: "<[project]/src/app/shared/auth-layout/or-separation.tsx>",
            lineNumber: 16,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/app/shared/auth-layout/or-separation.tsx>",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}

})()),
"[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>AuthWrapperOne
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$company$2d$logo$2e$jpg$2e$mjs$2f28$IMAGE$292f5b$project$5d2f$public$2f$company$2d$logo$2e$jpg__$5b$app$2d$ssr$5d$__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__("[project]/public/company-logo.jpg.mjs/(IMAGE)/[project]/public/company-logo.jpg [app-ssr] (static) (structured image object, ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__ = __turbopack_import__("[project]/node_modules/rizzui/dist/index.mjs [app-ssr] (ecmascript) {locals}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$pi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/pi/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fc$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fc/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$shared$2f$auth$2d$layout$2f$or$2d$separation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/shared/auth-layout/or-separation.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-hot-toast/dist/index.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
;
;
function AuthWrapperOne({ children, title, bannerTitle, bannerDescription, description, pageImage, isSocialLoginActive = false, isSignIn = false }) {
    function handleSignIn() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].error(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
            children: [
                "This is only demo purpose, click on the",
                ' ',
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
                    as: "b",
                    className: "font-semibold text-gray-900",
                    children: "Sign In"
                }, void 0, false, {
                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                    lineNumber: 36,
                    columnNumber: 9
                }, this),
                ' ',
                "button to login."
            ]
        }, void 0, true, {
            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
            lineNumber: 34,
            columnNumber: 7
        }, this));
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                href: '/',
                className: "sticky start-0 top-0 z-20 flex items-center justify-center bg-blue p-3.5 text-sm font-medium text-white md:p-4 lg:hidden",
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$pi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PiArrowLeftBold"], {}, void 0, false, {
                        fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
                        className: "ms-1 font-lexend",
                        children: "Back to home"
                    }, void 0, false, {
                        fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "min-h-screen justify-between gap-x-8 px-4 py-8 pt-10 md:pt-12 lg:flex lg:p-6 xl:gap-x-10 xl:p-7 2xl:p-10 2xl:pt-10 [&>div]:min-h-[calc(100vh-80px)]",
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "relative flex w-full items-center justify-center lg:w-5/12 2xl:justify-end 2xl:pe-24",
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            className: " w-full max-w-sm md:max-w-md lg:py-7 lg:ps-3 lg:pt-16 2xl:w-[630px] 2xl:max-w-none 2xl:ps-20 2xl:pt-7",
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: '/',
                                    className: "absolute -top-4 start-0 hidden p-3 text-gray-500 hover:text-gray-700 lg:flex lg:items-center 2xl:-top-7 2xl:ps-20 ",
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$pi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PiArrowLeftBold"], {}, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 60,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("b", {
                                            className: "ms-1 font-medium",
                                            children: "Back to home"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "mb-7 px-6 pt-3 text-center md:pt-0 lg:px-0 lg:text-start xl:mb-8 2xl:mb-10",
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: '/',
                                            className: "mb-6 inline-flex max-w-[168px] xl:mb-8",
                                            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$company$2d$logo$2e$jpg$2e$mjs$2f28$IMAGE$292f5b$project$5d2f$public$2f$company$2d$logo$2e$jpg__$5b$app$2d$ssr$5d$__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                alt: "Isomorphic"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                lineNumber: 68,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Title"], {
                                            as: "h2",
                                            className: "mb-5 text-[26px] leading-snug md:text-3xl md:!leading-normal lg:mb-7 lg:pe-16 lg:text-[28px] xl:text-3xl 2xl:pe-8 2xl:text-4xl",
                                            children: title
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 75,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
                                            className: " leading-[1.85] text-gray-700 md:leading-loose lg:pe-8 2xl:pe-14",
                                            children: description
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 81,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                isSocialLoginActive && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "grid grid-cols-1 gap-4 pb-5 md:grid-cols-2 md:pb-6 xl:gap-5 xl:pb-7",
                                            children: [
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Button"], {
                                                    onClick: ()=>// it should be signIn('apple')
                                                        handleSignIn(),
                                                    variant: "outline",
                                                    className: "h-11 w-full",
                                                    children: [
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$pi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PiAppleLogoFill"], {
                                                            className: "me-2 h-4 w-4 shrink-0"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                            lineNumber: 96,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                                            className: "truncate",
                                                            children: "Signin With Apple"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                            lineNumber: 97,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                    lineNumber: 88,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Button"], {
                                                    variant: "outline",
                                                    onClick: ()=>// it should be signIn('google')
                                                        handleSignIn(),
                                                    className: "h-11 w-full",
                                                    children: [
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fc$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FcGoogle"], {
                                                            className: "me-2 h-4 w-4 shrink-0"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                            lineNumber: 107,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                                            className: "truncate",
                                                            children: "Signin With Google"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                            lineNumber: 108,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                                    lineNumber: 99,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 87,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$shared$2f$auth$2d$layout$2f$or$2d$separation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            title: "OR",
                                            className: "mb-5 2xl:mb-7",
                                            isCenter: true
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 111,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true),
                                children
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "hidden w-7/12 items-center justify-center rounded-[20px] bg-gray-50 px-6 dark:bg-gray-100/40 lg:flex xl:justify-start 2xl:px-16",
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            className: "pb-8 pt-10 text-center xl:pt-16 2xl:block 2xl:w-[1063px]",
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "mx-auto mb-10 max-w-sm pt-2 2xl:max-w-lg",
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Title"], {
                                            as: "h2",
                                            className: "mb-5 font-semibold !leading-normal lg:text-[26px] 2xl:px-10 2xl:text-[32px]",
                                            children: bannerTitle
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 121,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rizzui$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$locals$7d$__["Text"], {
                                            className: "leading-[1.85] text-gray-700 md:leading-loose 2xl:px-6",
                                            children: bannerDescription
                                        }, void 0, false, {
                                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                            lineNumber: 127,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                                    lineNumber: 120,
                                    columnNumber: 13
                                }, this),
                                pageImage
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                        lineNumber: 118,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/app/shared/auth-layout/auth-wrapper-one.tsx>",
                lineNumber: 53,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}

})()),
"[project]/src/app/auth/(forgot-password)/forgot-password-1/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=_636b99._.js.map