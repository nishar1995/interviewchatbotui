(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_cjs_transform_ts_9230ca._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_cjs_transform_ts_9230ca._.js",
  "chunks": [
    "chunks/_a6a23c._.js"
  ],
  "source": "dynamic"
});
