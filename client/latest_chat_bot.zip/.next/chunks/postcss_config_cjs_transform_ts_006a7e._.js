(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_cjs_transform_ts_3e0957._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_cjs_transform_ts_3e0957._.js",
  "chunks": [
    "chunks/node_modules_53c1e4._.js",
    "chunks/postcss_config_cjs_bd7af1._.js"
  ],
  "source": "dynamic"
});
