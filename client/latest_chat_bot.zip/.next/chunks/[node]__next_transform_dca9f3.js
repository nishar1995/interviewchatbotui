(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[node]__next_transform_dca9f3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[node]__next_transform_dca9f3.js",
  "chunks": [
    "chunks/[turbopack-node]__7bfe0c._.js",
    "chunks/postcss_config_cjs_transform_ts_8ccec2._.js"
  ],
  "source": "entry"
});
