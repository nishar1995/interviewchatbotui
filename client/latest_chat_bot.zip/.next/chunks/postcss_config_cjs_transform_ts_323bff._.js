(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_cjs_transform_ts_323bff._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_cjs_transform_ts_323bff._.js",
  "chunks": [
    "chunks/postcss_config_cjs_transform_ts_05adad._.js"
  ],
  "source": "dynamic"
});
